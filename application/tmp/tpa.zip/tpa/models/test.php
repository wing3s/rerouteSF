<?php
class test extends CI_Model
{
        public function __construct()
        {
                date_default_timezone_set('America/Los_Angeles');
                return;
        }

}

?>
